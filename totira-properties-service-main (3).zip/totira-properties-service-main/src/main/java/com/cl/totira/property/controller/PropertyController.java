/**
 * 
 */
package com.cl.totira.property.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cl.totira.property.dto.PropertyDto;
import com.cl.totira.property.dto.PropertySearchDto;
import com.cl.totira.property.dto.PropertyStatusDto;
import com.cl.totira.property.model.Area;
import com.cl.totira.property.model.Municipality;
import com.cl.totira.property.model.Property;
import com.cl.totira.property.service.PropertyService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author JoShi
 *
 */

@Tag(name = "Property Service", description = "Totira App Property APIs")
@RestController
@RequestMapping(path = "${api.prefix}/v1/property")
public class PropertyController {

	@Autowired
	PropertyService propertyService;

	@Operation(summary = "Get Properties", description = "Get All Properties", tags = { "Property Service" })
	@GetMapping("/all")
	public List<PropertyDto> getAllProperties() {
		return propertyService.getAllProperties();
	}

	@Operation(summary = "Get Property Details", description = "Get Property Details by ID", tags = { "Property Service" })
	@GetMapping("")
	public PropertyDto getPropertyById(@RequestParam(name = "propertyId") String propertyId) {
		return propertyService.getPropertyById(propertyId);
	}

	@Operation(summary = "Save Property", description = "Save Property Details", tags = { "Property Service" })
	@PostMapping("")
	public PropertyDto storeProperty(@RequestBody PropertyDto propertyDto) {
		return propertyService.storeProperty(propertyDto);
	}

	@Operation(summary = "Update Property", description = "Update Property Details", tags = { "Property Service" })
	@PutMapping("")
	public PropertyDto storeProperty(@RequestParam(name = "propertyId") String propertyId, @RequestBody PropertyDto propertyDto) {
		return propertyService.updateProperty(propertyId, propertyDto);
	}

	@Operation(summary = "Delete Property", description = "Delete Property Details by ID", tags = { "Property Service" })
	@DeleteMapping("")
	public ResponseEntity<?> deletePropertyById(@RequestParam(name = "propertyId") String propertyId) {
		if(propertyService.deletePropertyById(propertyId)){
			return ResponseEntity.ok("Removed Successfully!");
		} else {
			return ResponseEntity.internalServerError().body("Unable remove Properties");
		}
	}

	@Operation(summary = "Get location", description = "Get list of location", tags = { "Property Service" })
	@GetMapping("/location")
	public List<Area> getAllarea() {
		return propertyService.getAllarea();
	}

	@Operation(summary = "Get municipalities", description = "Get All municipalities based on location", tags = { "Property Service" })
	@GetMapping("/municipalitylist")
	public List<Municipality> getAllMunicipalityList(@RequestParam(name = "Area_num") int Area_num) {
		return propertyService.getAllMunicipalityList(Area_num);
	}

	@Operation(summary="Search Property", description = "Criteria based filter", tags = { "Property Service " })
	@PostMapping("/searchproperty")
	public List<Property> getByDtoCriteria(@RequestBody PropertySearchDto dto){
		return propertyService.getByDtoCriteria(dto);

	}

	@Operation(summary = "Get Property Type", description = "Get all Property Type in list", tags = { "Property Service" })
	@GetMapping("/propertyType")
	public List<String> getPropertyType() {
		return propertyService.getPropertyType();
	}


	@Operation(summary = "Property Status Check", description = "Property Status Check", tags = { "Property Service" })
	@GetMapping("propertyStatusCheck")
	public PropertyStatusDto checkPropertyHold(@RequestParam(name = "propertyId") String propertyId) {
		PropertyStatusDto status= propertyService.checkPropertyStatus(propertyId);
		return status;

	}

}
