/**
 * 
 */
package com.cl.totira.property.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cl.totira.property.model.Property;

/**
 * @author JoShi
 *
 */

@Repository
public interface PropertyRepository extends MongoRepository<Property, String>{

}
