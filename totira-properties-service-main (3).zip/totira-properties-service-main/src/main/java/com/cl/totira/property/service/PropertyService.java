/**
 * 
 */
package com.cl.totira.property.service;

import java.util.List;

import com.cl.totira.property.dto.PropertyDto;
import com.cl.totira.property.dto.PropertySearchDto;
import com.cl.totira.property.dto.PropertyStatusDto;
import com.cl.totira.property.model.Area;
import com.cl.totira.property.model.Municipality;
import com.cl.totira.property.model.Property;

/**
 * @author JoShi
 *
 */

public interface PropertyService {

	List<PropertyDto> getAllProperties();

	PropertyDto getPropertyById(String propertyId);

	PropertyDto storeProperty(PropertyDto propertyDto);

	PropertyDto updateProperty(String propertyId, PropertyDto propertyDto);

	boolean deletePropertyById(String propertyId);

	List<Area> getAllarea();

	List<Municipality> getAllMunicipalityList(int Area_num);

	List<Property> getByDtoCriteria(PropertySearchDto dto);

	List<String> getPropertyType();

	PropertyStatusDto checkPropertyStatus(String propertyId);

}
