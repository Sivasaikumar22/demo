/**
 * 
 */
package com.cl.totira.property.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cl.totira.property.common.TotiraPropertyConstants;
import com.cl.totira.property.dto.PropertyDto;
import com.cl.totira.property.dto.PropertySearchDto;
import com.cl.totira.property.dto.PropertyStatusDto;
import com.cl.totira.property.model.Area;
import com.cl.totira.property.model.Municipality;
import com.cl.totira.property.model.Property;
import com.cl.totira.property.repositories.AreaRepository;
import com.cl.totira.property.repositories.MunicipalityRepository;
import com.cl.totira.property.repositories.PropertyRepository;
import com.cl.totira.property.service.PropertyService;
import com.cl.totira.property.utils.MapperUtil;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

/**
 * @author JoShi
 *
 */

@Service
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	PropertyRepository propertyRepo;

	@Autowired
	MunicipalityRepository municipalityRepo;

	@Autowired
	AreaRepository areaRepo;

	@Autowired
	MapperUtil mapperUtil;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MongoOperations mongoOperations;



	@Override
	public List<PropertyDto> getAllProperties() {
		List<Property> list = propertyRepo.findAll();
		if (!list.isEmpty()) {
			return mapperUtil.map(list, PropertyDto.class);
		}
		return new ArrayList<PropertyDto>();
	}

	@Override
	public PropertyDto getPropertyById(String propertyId) {
		Optional<Property> optProperty = propertyRepo.findById(propertyId);
		if (optProperty.isPresent()) {
			return mapperUtil.map(optProperty.get(), PropertyDto.class);
		}
		return null;
	}

	@Override
	public PropertyDto storeProperty(PropertyDto propertyDto) {
		if (propertyDto != null) {
			Property property = mapperUtil.map(propertyDto, Property.class);
			property = propertyRepo.save(property);
			return mapperUtil.map(property, PropertyDto.class);
		}
		return null;
	}

	@Override
	public PropertyDto updateProperty(String propertyId, PropertyDto propertyDto) {
		if (StringUtils.isNotBlank(propertyId) && propertyDto != null) {
			Optional<Property> optProperty = propertyRepo.findById(propertyId);
			if (optProperty.isPresent()) {
				Property property = optProperty.get();
				property = mapperUtil.map(propertyDto, Property.class);
				property = propertyRepo.save(property);
				return mapperUtil.map(property, PropertyDto.class);
			}
		}
		return null;
	}

	@Override
	@Transactional
	public boolean deletePropertyById(String propertyId) {
		try {
			propertyRepo.deleteById(propertyId);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public List<Municipality> getAllMunicipalityList(int Area_num) {
		return municipalityRepo.findByAreaNum(Area_num);
	}

	@Override
	public List<Area> getAllarea() {
		return areaRepo.findAll();

	}

	@Override
	public List<Property> getByDtoCriteria(PropertySearchDto dto) {
		Query query= new Query();
		final List<Criteria> criterias=new ArrayList<>();
		if(dto.getArea() !=null && !dto.getArea().isEmpty())
			criterias.add(Criteria.where("Area").is(dto.getArea()));
		if(dto.getAreaCode() !=null && !dto.getAreaCode().isEmpty())
			criterias.add(Criteria.where("Area_code").is(dto.getAreaCode()));
		if(dto.getMunicipality() !=null && !dto.getMunicipality().isEmpty())
			criterias.add(Criteria.where("Municipality").is(dto.getMunicipality()));
		if(dto.getMunicipalityCode() !=null && !dto.getMunicipalityCode().isEmpty())
			criterias.add(Criteria.where("Municipality_code").is(dto.getMunicipalityCode()));
		if(dto.getBedrooms()!=null && !dto.getBedrooms().isEmpty())
			criterias.add(Criteria.where("Br").is(Integer.parseInt(dto.getBedrooms())));
		if(dto.getMinRent() !=null && !dto.getMinRent().isEmpty())
			criterias.add(Criteria.where("Lp_dol").gte(Double.parseDouble( dto.getMinRent())));
		if(dto.getMaxRent() !=null && !dto.getMaxRent().isEmpty())
			criterias.add(Criteria.where("Lp_dol").lte(Double.parseDouble(dto.getMaxRent())));
		if(dto.getPetsAllowed() !=null && !dto.getPetsAllowed().isEmpty())
			//criterias.add(Criteria.where("pets_allowed").is(dto.getPetsAllowed()).and("pets_allowed").is(" "));
			criterias.add(new Criteria().orOperator(Criteria.where("pets_allowed").is(dto.getPetsAllowed()),Criteria.where("pets_allowed").is(" "),Criteria.where("pets_allowed").is("")));
		if(dto.getPropertyType() !=null && !dto.getPropertyType().isEmpty())
			criterias.add(Criteria.where("Type_own1_out").is(dto.getPropertyType()));
		if(dto.getBathroom() !=null && !dto.getBathroom().isEmpty())
			criterias.add(Criteria.where("Bath_tot").is(Integer.parseInt(dto.getBathroom())));
		if(dto.getLeaseTerm() !=null && !dto.getLeaseTerm().isEmpty())
			criterias.add(Criteria.where("Lease_term").is(dto.getLeaseTerm()));
		if(dto.getParking() !=null && !dto.getParking().isEmpty())
			criterias.add(Criteria.where("Park_spcs").is((Double.parseDouble(dto.getParking()))));

		if(dto.getAcMust() !=null && !dto.getAcMust().isEmpty()) {
			if(dto.getAcMust().trim().equalsIgnoreCase("Y")) {
				criterias.add(Criteria.where("A_c").nin("None", TotiraPropertyConstants.SPACE, TotiraPropertyConstants.BLANK));
			}else {
				criterias.add(Criteria.where("A_c").in("None",TotiraPropertyConstants.SPACE, TotiraPropertyConstants.BLANK));
			}
		}
		if(dto.getLaundryMust() !=null && !dto.getLaundryMust().isEmpty())
		{
			System.out.println("dto.getLaundryMust():"+dto.getLaundryMust());
			if(dto.getLaundryMust().trim().equalsIgnoreCase("Y"))
				criterias.add(Criteria.where("Laundry").nin("None", TotiraPropertyConstants.SPACE, TotiraPropertyConstants.BLANK));
			else
				criterias.add(Criteria.where("Laundry").in("None", TotiraPropertyConstants.SPACE, TotiraPropertyConstants.BLANK));
		}
		if(dto.getParkingMust() !=null && !dto.getParkingMust().isEmpty())
		{
			if(dto.getParkingMust().trim().equalsIgnoreCase("Y"))
				criterias.add(Criteria.where("Park_spcs").gt(0));
			else
				criterias.add(Criteria.where("Park_spcs").is(0));
		}

		Criteria criteria = new Criteria();        
		//Gym
		if(dto.getGymMust() !=null && !dto.getGymMust().isEmpty() && dto.getGymMust().trim().equalsIgnoreCase("Y"))
		{
			criteria = new Criteria();   
			criteria.orOperator(Criteria.where("Ad_text").is("%Gym%"),
					Criteria.where("Extras").regex("%Gym%"));
			criterias.add(criteria);
		}		
		if(dto.getPoolMust() !=null && !dto.getPoolMust().isEmpty() && dto.getPoolMust().trim().equalsIgnoreCase("Y"))
			criterias.add(Criteria.where("Pool").nin("None", TotiraPropertyConstants.SPACE, TotiraPropertyConstants.BLANK));

		if(dto.getWorshipProximity() !=null && !dto.getWorshipProximity().isEmpty() && dto.getWorshipProximity().trim().equalsIgnoreCase("Y"))
		{
			System.out.println("dto.getWorshipProximity():"+dto.getWorshipProximity());

			criteria = new Criteria();   
			criteria.orOperator(Criteria.where("Prop_feat1_out").is("Place Of Worship"),
					Criteria.where("Prop_feat2_out").is("Place Of Worship"),
					Criteria.where("Prop_feat3_out").is("Place Of Worship"),
					Criteria.where("Prop_feat4_out").is("Place Of Worship"),
					Criteria.where("Prop_feat5_out").is("Place Of Worship"),
					Criteria.where("Prop_feat6_out").is("Place Of Worship"));
			criterias.add(criteria);
		}
		if(dto.getSchoolProximity() !=null && !dto.getSchoolProximity().isEmpty() && dto.getSchoolProximity().trim().equalsIgnoreCase("Y"))
		{
			System.out.println("dto.getSchoolProximity():"+dto.getSchoolProximity());
			criteria = new Criteria();   
			criteria.orOperator(Criteria.where("Prop_feat1_out").is("School"),
					Criteria.where("Prop_feat2_out").is("School"),
					Criteria.where("Prop_feat3_out").is("School"),
					Criteria.where("Prop_feat4_out").is("School"),
					Criteria.where("Prop_feat5_out").is("School"),
					Criteria.where("Prop_feat6_out").is("School"));
			criterias.add(criteria);
		}
		if(dto.getHospitalProximity() !=null && !dto.getHospitalProximity().isEmpty() && dto.getHospitalProximity().trim().equalsIgnoreCase("Y"))
		{
			criteria = new Criteria();   
			criteria.orOperator(Criteria.where("Prop_feat1_out").is("Hospital"),
					Criteria.where("Prop_feat2_out").is("Hospital"),
					Criteria.where("Prop_feat3_out").is("Hospital"),
					Criteria.where("Prop_feat4_out").is("Hospital"),
					Criteria.where("Prop_feat5_out").is("Hospital"),
					Criteria.where("Prop_feat6_out").is("Hospital"));
			criterias.add(criteria);
		}
		if(dto.getParksProximity() !=null && !dto.getParksProximity().isEmpty() && dto.getParksProximity().trim().equalsIgnoreCase("Y"))
		{
			criteria = new Criteria();   
			criteria.orOperator(Criteria.where("Prop_feat1_out").is("Park"),
					Criteria.where("Prop_feat2_out").is("Park"),
					Criteria.where("Prop_feat3_out").is("Park"),
					Criteria.where("Prop_feat4_out").is("Park"),
					Criteria.where("Prop_feat5_out").is("Park"),
					Criteria.where("Prop_feat6_out").is("Park"));
			criterias.add(criteria);
		}
		//Malls
		if(dto.getMallsProximity() !=null && !dto.getMallsProximity().isEmpty()&& dto.getMallsProximity().trim().equalsIgnoreCase("Y"))
		{
			criteria = new Criteria();   
			criteria.orOperator(Criteria.where("Ad_text").is("%Mall%"),
					Criteria.where("Extras").regex("%Mall%"));
			criterias.add(criteria);
		}

		criterias.add(Criteria.where("Status").is("A"));
		criterias.add(Criteria.where("totiraStatus").is(TotiraPropertyConstants.PROPERTY_AVAILABLE));
		if(!criterias.isEmpty())
			query.addCriteria(new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()])));
		System.out.println(query.toString());
		return mongoTemplate.find(query, Property.class);
	}

	@Override
	public List<String> getPropertyType() {
		List<String> propertyTypeList = new ArrayList<>();
		MongoCollection mongoCollection = mongoTemplate.getCollection("property");
		DistinctIterable<String> distinctIterable = mongoCollection.distinct("Type_own1_out",String.class);
		MongoCursor<String> cursor = distinctIterable.iterator();
		while (cursor.hasNext()) {
			String type = (String)cursor.next();
			propertyTypeList.add(type);
		}

		return propertyTypeList;
	}

	@Override
	public PropertyStatusDto checkPropertyStatus(String propertyId) {
		PropertyDto dto= getPropertyById(propertyId);
		if(dto!=null) {
			PropertyStatusDto statusDto=new PropertyStatusDto();
			statusDto.setPropertyId(dto.getId());
			statusDto.setTotiraStatus(dto.getTotiraStatus());
			statusDto.setTotiraLastUpdatedTime(dto.getTotiraLastUpdatedTime());
			String totiraLastUpdatedTime= dto.getTotiraLastUpdatedTime();
			//Add date check
			return statusDto;
		}else {
			PropertyStatusDto statusDto=new PropertyStatusDto();
			statusDto.setPropertyId(propertyId);
			statusDto.setTotiraStatus("Property Details Not Available");
			return statusDto;
		}
	}
}
