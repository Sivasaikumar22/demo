package com.cl.totira.property.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PropertySearchDto {

	
	private String id;
	
	private String areaCode;
	private String area;
	private String municipality;
	private String municipalityCode;
	private String bedrooms;
	private String minRent;
	private String maxRent;
	private String petsAllowed;
	private String propertyType;
	private String bathroom;
	private String parking;
	private String leaseTerm;
	private String acMust;
	private String laundryMust;
	private String gymMust;
	private String poolMust;
	private String parkingMust;

	private String worshipProximity;
	private String schoolProximity;
	private String hospitalProximity;
	private String parksProximity;
	private String mallsProximity;
	private String totiraStatus;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getMunicipality() {
		return municipality;
	}
	public void setMunicipality(String municipality) {
		this.municipality = municipality;
	}
	public String getMunicipalityCode() {
		return municipalityCode;
	}
	public void setMunicipalityCode(String municipalityCode) {
		this.municipalityCode = municipalityCode;
	}
	public String getBedrooms() {
		return bedrooms;
	}
	public void setBedrooms(String bedrooms) {
		this.bedrooms = bedrooms;
	}
	public String getMinRent() {
		return minRent;
	}
	public void setMinRent(String minRent) {
		this.minRent = minRent;
	}
	public String getMaxRent() {
		return maxRent;
	}
	public void setMaxRent(String maxRent) {
		this.maxRent = maxRent;
	}
	public String getPetsAllowed() {
		return petsAllowed;
	}
	public void setPetsAllowed(String petsAllowed) {
		this.petsAllowed = petsAllowed;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public String getBathroom() {
		return bathroom;
	}
	public void setBathroom(String bathroom) {
		this.bathroom = bathroom;
	}
	public String getParking() {
		return parking;
	}
	public void setParking(String parking) {
		this.parking = parking;
	}
	public String getLeaseTerm() {
		return leaseTerm;
	}
	public void setLeaseTerm(String leaseTerm) {
		this.leaseTerm = leaseTerm;
	}
	
	public String getWorshipProximity() {
		return worshipProximity;
	}
	public void setWorshipProximity(String worshipProximity) {
		this.worshipProximity = worshipProximity;
	}
	public String getSchoolProximity() {
		return schoolProximity;
	}
	public void setSchoolProximity(String schoolProximity) {
		this.schoolProximity = schoolProximity;
	}
	public String getHospitalProximity() {
		return hospitalProximity;
	}
	public void setHospitalProximity(String hospitalProximity) {
		this.hospitalProximity = hospitalProximity;
	}
	public String getParksProximity() {
		return parksProximity;
	}
	public void setParksProximity(String parksProximity) {
		this.parksProximity = parksProximity;
	}
	public String getMallsProximity() {
		return mallsProximity;
	}
	public void setMallsProximity(String mallsProximity) {
		this.mallsProximity = mallsProximity;
	}
	public String getAcMust() {
		return acMust;
	}
	public void setAcMust(String acMust) {
		this.acMust = acMust;
	}
	public String getLaundryMust() {
		return laundryMust;
	}
	public void setLaundryMust(String laundryMust) {
		this.laundryMust = laundryMust;
	}
	public String getGymMust() {
		return gymMust;
	}
	public void setGymMust(String gymMust) {
		this.gymMust = gymMust;
	}
	public String getPoolMust() {
		return poolMust;
	}
	public void setPoolMust(String poolMust) {
		this.poolMust = poolMust;
	}
	public String getParkingMust() {
		return parkingMust;
	}
	public void setParkingMust(String parkingMust) {
		this.parkingMust = parkingMust;
	}
	public String getTotiraStatus() {
		return totiraStatus;
	}
	public void setTotiraStatus(String totiraStatus) {
		this.totiraStatus = totiraStatus;
	}
	@Override
	public String toString() {
		return "PropertySearchDto [id=" + id + ", areaCode=" + areaCode + ", area=" + area + ", municipality="
				+ municipality + ", municipalityCode=" + municipalityCode + ", bedrooms=" + bedrooms + ", minRent="
				+ minRent + ", maxRent=" + maxRent + ", petsAllowed=" + petsAllowed + ", propertyType=" + propertyType
				+ ", bathroom=" + bathroom + ", parking=" + parking + ", leaseTerm=" + leaseTerm + ", acMust=" + acMust
				+ ", laundryMust=" + laundryMust + ", gymMust=" + gymMust + ", poolMust=" + poolMust + ", parkingMust="
				+ parkingMust + ", worshipProximity=" + worshipProximity + ", schoolProximity=" + schoolProximity
				+ ", hospitalProximity=" + hospitalProximity + ", parksProximity=" + parksProximity
				+ ", mallsProximity=" + mallsProximity + ", totiraStatus=" + totiraStatus + "]";
	}
	
}