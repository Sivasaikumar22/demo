/**
 * 
 */
package com.cl.totira.property.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author JoShi
 *
 */

@Data
@NoArgsConstructor
public class PropertyStatusDto {

	private String propertyId;
	private String totiraStatus;
	private String totiraLastUpdatedTime;

	public String getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}
	public String getTotiraStatus() {
		return totiraStatus;
	}
	public void setTotiraStatus(String totiraStatus) {
		this.totiraStatus = totiraStatus;
	}
	public String getTotiraLastUpdatedTime() {
		return totiraLastUpdatedTime;
	}
	public void setTotiraLastUpdatedTime(String totiraLastUpdatedTime) {
		this.totiraLastUpdatedTime = totiraLastUpdatedTime;
	}
	
	

}
