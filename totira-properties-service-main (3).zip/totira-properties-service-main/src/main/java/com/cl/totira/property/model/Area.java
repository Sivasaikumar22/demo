package com.cl.totira.property.model;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document("area")
public class Area {
	
	@Id
	private String id;
	private int Area_num;
	private String Area;
	private LocalDate last_update;
	private int update_type;
	private double lat;
	private double lng;
	
	public Area() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Area(String id, int area_num, String area, LocalDate last_update, int update_type, double lat, double lng) {
		super();
		this.id = id;
		Area_num = area_num;
		Area = area;
		this.last_update = last_update;
		this.update_type = update_type;
		this.lat = lat;
		this.lng = lng;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getArea_num() {
		return Area_num;
	}

	public void setArea_num(int area_num) {
		Area_num = area_num;
	}

	public String getArea() {
		return Area;
	}

	public void setArea(String area) {
		Area = area;
	}

	public LocalDate getLast_update() {
		return last_update;
	}

	public void setLast_update(LocalDate last_update) {
		this.last_update = last_update;
	}

	public int getUpdate_type() {
		return update_type;
	}

	public void setUpdate_type(int update_type) {
		this.update_type = update_type;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLng() {
		return lng;
	}

	public void setLng(double lng) {
		this.lng = lng;
	}

}
