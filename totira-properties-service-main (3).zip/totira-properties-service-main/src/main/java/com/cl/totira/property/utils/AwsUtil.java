package com.cl.totira.property.utils;

import java.net.URL;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;

import org.springframework.web.multipart.MultipartFile;

public class AwsUtil {

	public static URL uploadFieToS3(AmazonS3 amazonS3, String bucketName, String key, MultipartFile multipartFile)
			throws Exception {

		try {
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType(multipartFile.getContentType());
			metadata.setContentLength(multipartFile.getSize());
			PutObjectResult result = amazonS3
					.putObject(new PutObjectRequest(bucketName, key, multipartFile.getInputStream(), metadata)
							.withCannedAcl(CannedAccessControlList.PublicRead));
			System.out.println(result.toString());
			return amazonS3.getUrl(bucketName, key);
		} catch (Exception e) {
			throw e;
		}

	}

}
