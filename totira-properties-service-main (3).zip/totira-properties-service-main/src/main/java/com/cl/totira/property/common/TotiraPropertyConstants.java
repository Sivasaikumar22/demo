package com.cl.totira.property.common;

public class TotiraPropertyConstants {
	public static final String GT_CENTRAL_TORONTO = "C01,C02,C03,C04,C05,C06,C07,C08,C09,C10";
	public static final String GT_CENTRAL_EASTYORK = "C11";
	public static final String GT_CENTRAL_NORTHYORK= "C12,C13,C14,C15";

	public static final String GT_WEST_TORONTO= "W01";
	public static final String GT_WEST_TORONTO_YORK= "W02,W03";
	public static final String GT_WEST_NORTHYORK_YORK= "W04";
	public static final String GT_WEST_YORK= "W05";
	public static final String GT_WEST_ETOBICOKE= "W06,W07,W08,W09,W10";
	public static final String GT_WEST_MISSISSAUGA= "W12,W13,W14,W15,W16,W17,W18,W19,W20";
	public static final String GT_WEST_OAKVILLE ="W21";
	public static final String GT_WEST_MILTON ="W22";
	public static final String GT_WEST_BRAMPTON="W23,W24";
	public static final String GT_WEST_BURLINGTON="W25";
	public static final String GT_WEST_MILTONNORTH="W26";
	public static final String GT_WEST_HALTONHILLS="W27";
	public static final String GT_WEST_CALEDON="W28";
	public static final String GT_WEST_ORANGEVILLE="W29";
	
	public static final String GT_EAST_TORONTO = "E01,E02";
	public static final String GT_EAST_EASTYORK = "E03";
	public static final String GT_EAST_SCARBOROUGH = "E04,E05,E06,E07,E08,E09,E10,E11";
	public static final String GT_EAST_PICKERING = "E12,E13,E18";
	public static final String GT_EAST_AJAX = "E14";
	public static final String GT_EAST_WHITBY = "E15";
	public static final String GT_EAST_OSHAWA = "E16";
	public static final String GT_EAST_BOWMANVILLE = "E17";
	public static final String GT_EAST_NORTH = "E19,E21";
	public static final String GT_EAST_NEWCASTLE = "E20";
	
	public static final String PROPERTY_AVAILABLE = "Available";
	public static final String PROPERTY_ON_HOLD = "OnHold";
	public static final String PROPERTY_OCCUPIED= "Occupied";
	public static final String PROPERTY_LEASED_BY_OTHER_SITE= "LeasedByOtherSite";
	public static final String SPACE=" ";
	public static final String BLANK="";
	

	
}
