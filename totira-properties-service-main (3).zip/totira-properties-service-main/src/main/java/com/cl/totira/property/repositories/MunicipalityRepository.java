package com.cl.totira.property.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cl.totira.property.model.Municipality;

@Repository
public interface MunicipalityRepository extends MongoRepository<Municipality, String>{

	@Query(value="{'Area_num':?0}")
	List<Municipality> findByAreaNum(int Area_num);
	
	
}
