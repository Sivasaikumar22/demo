/**
 * 
 */
package com.cl.totira.property.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.dozer.CustomConverter;
import org.dozer.MappingException;

/**
 * @author JoShi
 *
 */

public class StringToLocalDateConverter implements CustomConverter {

	@Override
	public Object convert(Object existingDestinationFieldValue, Object sourceFieldValue, Class<?> destinationClass,
			Class<?> sourceClass) {
		if (sourceFieldValue == null)
			return null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		if (sourceFieldValue instanceof String) {
			String sourcedate = (String) sourceFieldValue;
			return LocalDate.parse(sourcedate, formatter);
		} else if (sourceFieldValue instanceof LocalDate) {
			LocalDate sourceDate = (LocalDate) sourceFieldValue;
			return sourceDate.format(formatter);
		}

		throw new MappingException("wrong mapping");

	}
}
