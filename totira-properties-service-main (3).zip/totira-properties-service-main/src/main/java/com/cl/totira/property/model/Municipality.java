package com.cl.totira.property.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data

@Document(collection = "municipality")
public class Municipality {
	
	@Id
	private String id;
	
	private int Area_num;
	private String Municipality;
	private String Municipality_code;
	private Double lat;
	private Double lng;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getArea_num() {
		return Area_num;
	}
	public void setArea_num(int area_num) {
		Area_num = area_num;
	}
	public String getMunicipality() {
		return Municipality;
	}
	public void setMunicipality(String municipality) {
		Municipality = municipality;
	}
	public String getMunicipality_code() {
		return Municipality_code;
	}
	public void setMunicipality_code(String municipality_code) {
		Municipality_code = municipality_code;
	}
	public Double getLat() {
		return lat;
	}
	public void setLat(Double lat) {
		this.lat = lat;
	}
	public Double getLng() {
		return lng;
	}
	public void setLng(Double lng) {
		this.lng = lng;
	}
	
	

}
